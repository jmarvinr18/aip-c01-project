import json
import boto3
import os
import urllib.parse
from urllib.parse import urlparse
from pathlib import Path

s3 = boto3.client("s3", region_name="ap-southeast-1")
ba_client = boto3.client("bedrock-agent-runtime", region_name="ap-southeast-1")


def lambda_handler(event, context):

    ba_response = ba_client.retrieve(knowledgeBaseId="SI1PK19NAO", input={
                                     "text": "what is ai stages?"}, retrievalQuery={
                                         "type": "TEXT", "text": "what is ai stages?"})

    return {"ba_response": ba_response, "statusCode": 200, "body": json.dumps(ba_response)}
